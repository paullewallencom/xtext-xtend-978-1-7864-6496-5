package entities;

public class MyEntity {

}
