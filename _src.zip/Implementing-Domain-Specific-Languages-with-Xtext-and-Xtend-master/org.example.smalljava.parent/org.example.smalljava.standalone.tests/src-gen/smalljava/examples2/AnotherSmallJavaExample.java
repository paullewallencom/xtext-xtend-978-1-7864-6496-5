package smalljava.examples2;

public class AnotherSmallJavaExample {
	public String hello(Boolean b) {
		String result = null;
		if (b)
			{
				result = "Hallo";
			}
		else
			{
				result = "Hello";
			}
		return result;
	}
}
