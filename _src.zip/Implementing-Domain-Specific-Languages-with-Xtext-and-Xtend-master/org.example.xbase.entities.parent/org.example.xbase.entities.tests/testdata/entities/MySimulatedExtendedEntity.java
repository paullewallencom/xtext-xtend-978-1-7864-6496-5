package entities;

/**
 * This simulates an entity, and it is used to test
 * the validator and cycles in hierarchy.
 * 
 * @author Lorenzo Bettini
 *
 */
public class MySimulatedExtendedEntity extends MySimulatedEntity {

}
