package org.example.guice.modules;

import org.example.guice.Utility;

public class CustomUtility extends Utility {

    @Override
    public String m() {
        return "customutility.m";
    }
}
