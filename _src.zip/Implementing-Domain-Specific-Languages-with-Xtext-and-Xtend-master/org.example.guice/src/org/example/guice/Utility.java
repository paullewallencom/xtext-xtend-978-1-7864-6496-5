package org.example.guice;

public class Utility {
    public String m() {
        return "utility.m";
    }
}
