package org.example.guice;


public interface Processor {
	public void process(Object o);
}
