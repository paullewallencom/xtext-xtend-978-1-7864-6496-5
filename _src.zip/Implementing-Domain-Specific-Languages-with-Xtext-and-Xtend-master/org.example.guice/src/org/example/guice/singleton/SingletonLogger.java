package org.example.guice.singleton;

import org.example.guice.Logger;

import com.google.inject.Singleton;

@Singleton
public class SingletonLogger extends Logger {

}
