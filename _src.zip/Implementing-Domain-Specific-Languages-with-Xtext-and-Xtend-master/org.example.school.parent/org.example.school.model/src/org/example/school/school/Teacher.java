/**
 */
package org.example.school.school;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Teacher</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.example.school.school.SchoolPackage#getTeacher()
 * @model
 * @generated
 */
public interface Teacher extends Person {
} // Teacher
