/**
 */
package org.example.school.school;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Person</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.example.school.school.SchoolPackage#getPerson()
 * @model abstract="true"
 * @generated
 */
public interface Person extends Named {
} // Person
