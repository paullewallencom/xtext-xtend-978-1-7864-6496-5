/**
 */
package org.example.school.school.impl;

import org.eclipse.emf.ecore.EClass;

import org.example.school.school.Person;
import org.example.school.school.SchoolPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Person</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class PersonImpl extends NamedImpl implements Person {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PersonImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SchoolPackage.Literals.PERSON;
	}

} //PersonImpl
